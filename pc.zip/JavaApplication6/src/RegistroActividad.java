import java.util.ArrayList;
import java.util.List;

public class RegistroActividad {
    private static RegistroActividad instancia;
    private List<Actividad> actividades;

    private RegistroActividad() {
        actividades = new ArrayList<>();
    }

    public static RegistroActividad getInstance() {
        if (instancia == null) {
            instancia = new RegistroActividad();
        }
        return instancia;
    }

    // Método para registrar una actividad
    public void registrar(Actividad actividad) {
        if (actividad == null) {
            throw new IllegalArgumentException("La actividad no puede ser nula");
        }
        actividades.add(actividad);
        System.out.println("Actividad registrada: " + actividad.getTipo());
    }

    // Método para mostrar todas las actividades registradas
    public void mostrarActividades() {
        System.out.println("Actividades registradas:");
        for (Actividad actividad : actividades) {
            System.out.println(actividad.getTipo() + " - " + actividad.getDuracion() + " minutos");
        }
    }
}
