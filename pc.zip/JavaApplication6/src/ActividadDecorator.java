public abstract class ActividadDecorator extends Actividad {
    protected Actividad actividad;

    public ActividadDecorator(Actividad actividad) {
        super(actividad.getTipo(), actividad.getDuracion());
        this.actividad = actividad;
    }

    @Override
    public String getDescripcion() {
        return actividad.getDescripcion();
    }
}
