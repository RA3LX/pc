
import java.util.ArrayList;
import java.util.List;

public class ActividadCombinada extends Actividad {
    private List<Actividad> actividades = new ArrayList<>();

    public ActividadCombinada(String tipo, int duracion) {
        super(tipo, duracion);
    }

    public void addActividad(Actividad actividad) {
        actividades.add(actividad);
    }

    public void removeActividad(Actividad actividad) {
        actividades.remove(actividad);
    }

    public List<Actividad> getActividades() {
        return actividades;
    }
}
