public class SistemaFacade {
    private RegistroActividad registro;

    public SistemaFacade() {
        this.registro = RegistroActividad.getInstance();
    }

    public void registrarActividad(String tipo, int duracion) {
        Actividad actividad = ActividadFactory.crearActividad(tipo, duracion);
        registro.registrar(actividad);
    }
}
