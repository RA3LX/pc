public class Actividad implements Cloneable {

    private String tipo;
    private int duracion;

    public Actividad(String tipo, int duracion) {
        this.tipo = tipo;
        this.duracion = duracion;
    }

    public String getTipo() {
        return tipo;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public Actividad clone() throws CloneNotSupportedException {
        return (Actividad) super.clone();
    }

    String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
