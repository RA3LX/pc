import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        // Crear el registro de actividades utilizando el patrón Singleton
        RegistroActividad registro = RegistroActividad.getInstance();

        // Crear algunas actividades
        Actividad correr = new Actividad("Correr", 30);
        Actividad nadar = new Actividad("Nadar", 60);

        // Registrar actividades
        registro.registrar(correr);
        registro.registrar(nadar);

        // Mostrar actividades registradas
        registro.mostrarActividades();

        // Conectar a la base de datos
        try {
            Connection connection = conectarBaseDeDatos();
            System.out.println("Conexión a la base de datos exitosa.");
            // Aquí puedes realizar operaciones con la base de datos
            connection.close(); // Cerrar la conexión
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }

    // Método para conectar a la base de datos
    private static Connection conectarBaseDeDatos() throws SQLException {
    // Cambia 'TuBaseDeDatos' por el nombre real de tu base de datos
    String url = "jdbc:sqlserver://localhost:1433;databaseName=TuBaseDeDatos;integratedSecurity=true";

    // Establecer la conexión
    return DriverManager.getConnection(url);
    }
}
