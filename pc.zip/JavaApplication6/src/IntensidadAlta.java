public class IntensidadAlta extends ActividadDecorator {

    public IntensidadAlta(Actividad actividad) {
        super(actividad);
    }

    @Override
    public String getDescripcion() {
        return actividad.getDescripcion() + " con intensidad alta.";
    }
}
