public class ActividadFactory {
    public static Actividad crearActividad(String tipo, int duracion) {
        switch (tipo) {
            case "Correr" -> {
                return new Actividad("Correr", duracion);
            }
            case "Caminar" -> {
                return new Actividad("Caminar", duracion);
            }
            default -> throw new IllegalArgumentException("Tipo de actividad no soportado");
        }
    }
}
