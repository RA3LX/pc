import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class RegistroActividadTest1 {

    @Test
    public void testSingleton() {
        // Obtener la instancia Singleton de RegistroActividad
        RegistroActividad registro1 = RegistroActividad.getInstance();
        RegistroActividad registro2 = RegistroActividad.getInstance();

        // Verificar que ambas instancias sean iguales
        assertEquals(registro1, registro2);  // Ambas instancias deben ser la misma
    }

    @Test
    public void testPrototype() throws CloneNotSupportedException {
        // Crear una instancia original de Actividad
        Actividad original = new Actividad("Correr", 30);

        // Clonar la instancia original
        Actividad clonada = original.clone();

        // Verificar que el tipo de la actividad clonada sea igual al original
        assertEquals(original.getTipo(), clonada.getTipo());
    }
}
