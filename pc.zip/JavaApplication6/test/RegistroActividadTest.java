import org.junit.jupiter.api.Test;

public class RegistroActividadTest {

    @Test
    public void testRegistroActividad() {
        // Crear instancia de SistemaFacade para registrar actividades
        SistemaFacade facade = new SistemaFacade();
        
        // Registrar una actividad
        facade.registrarActividad("Correr", 30);
       
    }
}
